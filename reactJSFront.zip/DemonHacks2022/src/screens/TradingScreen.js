import React from "react";
import {Text, StyleSheet, View, ScrollView} from "react-native";
import { Box, Flex, Button} from "@react-native-material/core";


const TradingScreen = () => {
  return (
    <Flex style={styles.flex} >
        <Text style={styles.text1}> Welcome to Trading</Text>
      <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.viewBox} w={300} h={150} style={styles.box}>
          <Text style={styles.text}>User "null" is Offering:</Text>
          <View style={styles.viewStyle1}></View>
          <Text style={styles.text}>10 Kit-Kat for 5 Skittles</Text>
          <View style={styles.viewStyle}></View>
          <Button style={styles.box2} title='Trade or Counteroffer'/>
      </View>

      <View style={styles.viewBox} w={300} h={150} style={styles.box}>
          <Text style={styles.text}>User "null" is Offering:</Text>
          <View style={styles.viewStyle1}></View>
          <Text style={styles.text}>9 Airheads for 5 Reeses</Text>
          <View style={styles.viewStyle}></View>
          <Button style={styles.box2} title='Trade or Counteroffer'/>
      </View>

      <View style={styles.viewBox} w={300} h={150} style={styles.box}>
          <Text style={styles.text}>User "null" is Offering:</Text>
          <View style={styles.viewStyle1}></View>
          <Text style={styles.text}>2 Kit-Kat for 1 Butterfinger</Text>
          <View style={styles.viewStyle}></View>
          <Button style={styles.box2} title='Trade or Counteroffer'/>
      </View>

      <View style={styles.viewBox} w={300} h={150} style={styles.box}>
          <Text style={styles.text}>User "null" is Offering:</Text>
          <View style={styles.viewStyle1}></View>
          <Text style={styles.text}>15 Twix for 2 Reeses</Text>
          <View style={styles.viewStyle}></View>
          <Button style={styles.box2} title='Trade or Counteroffer'/>
      </View>

      <View style={styles.viewBox} w={300} h={150} style={styles.box}>
          <Text style={styles.text}>User "null" is Offering:</Text>
          <View style={styles.viewStyle1}></View>
          <Text style={styles.text}>13 Reeses for 70 Twizzlers</Text>
          <View style={styles.viewStyle}></View>
          <Button style={styles.box2} title='Trade or Counteroffer'/>
      </View>

      <View style={styles.viewBox} w={300} h={150} style={styles.box}>
          <Text style={styles.text}>User "null" is Offering:</Text>
          <View style={styles.viewStyle1}></View>
          <Text style={styles.text}>8 Hershey's Kisses for 1 Payday Bar</Text>
          <View style={styles.viewStyle}></View>
          <Button style={styles.box2} title='Trade or Counteroffer'/>
      </View>
      </ScrollView>
    </Flex>
  );
};

const styles = StyleSheet.create({
  flex: {
    alignItems: 'center',
  },
  box: {
    borderWidth:2,
    margin: 10,
    backgroundColor:'gray',
  },
  box1: {
    borderWidth:2,
    margin: 1,
  },
  box2: {
    alignItems: 'center',

  },
  text: {
    fontSize: 15,
    padding: 10,
    textAlign: 'center',
    
  },
  text1: {
    fontSize: 30,
    padding: 10,
    textAlign: 'center',
    
  },
  viewStyle: {
    margin: 55,
    textAlign: 'center',
  },
  viewStyle: {
    margin: 15,
    textAlign: 'center',
  },
  viewBox: {
    borderWidth: 2,
    margin: 50,
  },
});

export default TradingScreen;
