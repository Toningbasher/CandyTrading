import React from "react";
import {StyleSheet, View,TouchableOpacity} from "react-native";
import { Button } from "@react-native-material/core";
import { Text } from "@react-native-material/core";
import { Flex, Box, Spacer } from 'react-native-flex-layout';

const MainScreen = ({ navigation }) => {
  return (
    <View>
      <Text style={styles.text}>Welcome to Trade or Treat!</Text>
      <Text style={styles.text}>Happy Trading!</Text>

      <View style={styles.space}/>
      
      <View style={styles.viewBox}>
      <Button title='My Candy' onPress={() => {navigation.navigate('Candy')}}/>
      </View>
      
      <View style={styles.viewBox}>
        <Button title='Trading'onPress={() => {navigation.navigate('Trading')}}/>
      </View>

      <View style={styles.viewBox}>
        <Button title='Account'onPress={() => {navigation.navigate('Accounts')}}/>
      </View>

    </View>
  );
};

const styles = StyleSheet.create({
  text: {
    height: 60,
    fontSize: 30,
    padding: 5,
    textAlign: 'center',
    
  },
  space: {
    height: 30,
  },
  viewBox: {
    borderWidth: 2,
    margin: 50,
  },
  buttonPad: {
    padding: 10,
  }
});

export default MainScreen;
