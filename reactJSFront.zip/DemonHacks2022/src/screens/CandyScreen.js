import React, { useState, Component, AsyncStorage } from "react";
import { StyleSheet, Text, View, ScrollView, Keyboard, FlatList} from 'react-native';
import {Button, TextInput} from "@react-native-material/core";

const CandyScreen = () => {
  const candyQuant =[
    {Candy:'Kit-Kat', Quantity: '2'},
    {Candy:'Twizzler', Quantity: '9'},
    {Candy:'Twix', Quantity: '20'},
    {Candy:'Reeses', Quantity: '12'},
    {Candy:'Butterfinger', Quantity: '6'},
    {Candy:'Skittles', Quantity: '5'},
];  
  return (
      <View style={styles.container}>
        <View>
          <Text style={styles.header}>My Candy</Text>
          <ScrollView>
            <View style={styles.inputContainer}>
              <TextInput
              label='Enter Candy and Quantity'
             //onChangeText={input => setCandyQuant(candyQuant)}
              //onSubmitEditing={(value) => {
              //setCandyQuant(value.nativeEvent.text)}}
              />
            </View>
            <View style={styles.viewBox}>
              <Button 
              title='Save' 
              />
            </View>
          </ScrollView>
          
          <View style={styles.View}>
            <FlatList
              style={styles.flatlist} 
              showVerticalScrollIndicator={false}
              keyExtractor={(input) => candyQuant.Candy}
              data={candyQuant}
              renderItem={({ item }) => {
              return <Text styles={{textAlign:'center', padding: 4}}>                  Candy: {item.Candy} - Quantity: {item.Quantity}</Text>;
              }}
            />
          </View>
        </View>
      </View>
    );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 45,
    backgroundColor: '#F5FCFF',
    textAlign: 'center',
  },
  header: {
    fontSize: 25,
    textAlign: 'center',
    margin: 10,
    fontWeight: 'bold'
  },
  inputContainer: {
    paddingTop: 15
  },
  textInput: {
    borderColor: '#CCCCCC',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    height: 50,
    fontSize: 25,
    paddingLeft: 20,
    paddingRight: 20
  },
  saveButton: {
    borderWidth: 1,
    borderColor: '#007BFF',
    backgroundColor: '#007BFF',
    padding: 15,
    margin: 5
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 20,
    textAlign: 'center'
  },
  viewBox: {
    borderWidth: 2,
    margin: 50,
  },
  view: {
    alignItems:'center',
  },
  flatlist: {
    borderWidth: 3,
    margin: 30,
  },
  textStyle: {
    textAlign:'center',
  },
});

export default CandyScreen;