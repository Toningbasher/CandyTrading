import React, { useState } from 'react';
import { StyleSheet, View } from "react-native";
import { Text, TextInput, IconButton } from "@react-native-material/core";

const AccountScreen = () => {
    const [name, inputName] = useState('');
    const [email, inputEmail] = useState('');
    const [address, inputAddress] = useState('');
    
    return (    
        <View>
            <TextInput 
            variant="outlined" 
            label='First and Last'
            onChangeText={input => inputName(name)}
            onSubmitEditing={(value) => inputName(value.nativeEvent.text)}
             />
            <TextInput 
            variant="outlined" 
            label='Email' 
            onChangeText={input => inputEmail(email)}
            onSubmitEditing={(value) => inputEmail(value.nativeEvent.text)}
            />
            <TextInput  
            variant="outlined" 
            label='Address (Address Number, Street, City, State)' 
            onChangeText={input => inputAddress(address)}
            onSubmitEditing={(value) => inputAddress(value.nativeEvent.text)}
            />
            <View style={styles.space}> 
            <Text style={styles.text}>**Your data is VERY secure.**</Text>
            <Text style={styles.text}>(Trust us, we have a LOT of firewalls. I think...)</Text>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    space: {
      padding: 10,
    },
    text: {
        textAlign: 'center',
        fontSize: 15,
    }
});
export default AccountScreen;