import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import MainScreen from "./src/screens/MainScreen";
import CandyScreen from "./src/screens/CandyScreen";
import TradingScreen from "./src/screens/TradingScreen";
import AccountScreen from "./src/screens/AccountScreen";

const navigator = createStackNavigator(
  {
    Main: MainScreen,
    Candy: CandyScreen,
    Trading: TradingScreen,
    Accounts: AccountScreen,
  },
  {
    initialRouteName: 'Main',
    defaultNavigationOptions: {
      title: "",
    },
  }
);

export default createAppContainer(navigator);
